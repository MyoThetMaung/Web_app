<?php
//common start

use function PHPSTORM_META\type;

function alert($data, $color='danger'){
        return "<p class='alert alert-$color'>$data</p>";
    }

    function run_query($sql){
        if(mysqli_query(connection(),$sql)){
            return true;
        }else{
            die('query fail!');
        }
    }

    function redirect($location){
        header("Location: $location");
    }

//common end


// auth start 

    function register(){
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        if($password == $confirm_password){
            $secure_password = password_hash($password,PASSWORD_DEFAULT);                                               //password secure

            $sql = "INSERT INTO users (username,email,password) VALUES ('$username','$email','$secure_password')";
            if( run_query($sql)){
                redirect('login.php');
            }
        }else{
            alert("password not match!");
        }
    }


    function login(){
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE email = '$email'";
        $query = mysqli_query(connection(), $sql);
        $row = mysqli_fetch_assoc($query);
      
        if (!$row) {
            return alert('email or password not match!');
        } else {
            if (!password_verify($password, $row['password'])) {
                return alert("Wrong email or password!");
            } else {
                
                session_start();
                $_SESSION['user'] = $row;
                return redirect('dashboard.php');
                
            }
        }
    }

// auth end 
