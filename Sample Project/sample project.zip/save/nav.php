<div>

    <a href="create.php">Create</a>
    <a href="read.php">Show List</a>
    <br> <br>   
</div>